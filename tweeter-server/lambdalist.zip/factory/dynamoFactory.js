"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dynamoFactory = void 0;
const DynamoAuthDAO_1 = require("../dao/dynamodb/DynamoAuthDAO");
const DynamoFollowDAO_1 = require("../dao/dynamodb/DynamoFollowDAO");
const DynamoStatusDAO_1 = require("../dao/dynamodb/DynamoStatusDAO");
const DynamoUserDAO_1 = require("../dao/dynamodb/DynamoUserDAO");
const S3ProfileImageDAO_1 = require("../dao/s3/S3ProfileImageDAO");
class dynamoFactory {
    createUserDAO() {
        return new DynamoUserDAO_1.DynamoUserDAO();
    }
    createAuthenticationDAO() {
        return new DynamoAuthDAO_1.DynamoAuthDAO();
    }
    createFollowDAO() {
        return new DynamoFollowDAO_1.DynamoFollowDAO();
    }
    createProfileImageDAO() {
        return new S3ProfileImageDAO_1.S3ProfileImageDAO();
    }
    createStatusDAO() {
        return new DynamoStatusDAO_1.DynamoStatusDAO();
    }
}
exports.dynamoFactory = dynamoFactory;
