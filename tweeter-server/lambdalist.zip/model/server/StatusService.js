"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatusService = void 0;
class StatusService {
    statusDAO;
    constructor(statusDAO) {
        this.statusDAO = statusDAO;
    }
    async loadMoreStoryItems(token, userAlias, pageSize, lastItem) {
        const { statuses, hasMore } = await this.statusDAO.getStoryItems(userAlias, pageSize, lastItem);
        return [statuses, hasMore];
    }
    ;
    async loadMoreFeedItems(token, userAlias, pageSize, lastItem) {
        const { statuses, hasMore } = await this.statusDAO.getFeedItems(userAlias, pageSize, lastItem);
        return [statuses, hasMore];
    }
    ;
    async postStatus(token, newStatus) {
        await this.statusDAO.writeToStory(newStatus);
    }
    ;
    async writeStatusToFeed(followerAlias, status) {
        await this.statusDAO.writeStatusToFeed(followerAlias, status);
    }
}
exports.StatusService = StatusService;
