"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FollowService = void 0;
class FollowService {
    followDAO;
    constructor(followDAO) {
        this.followDAO = followDAO;
    }
    async loadMoreFollowers(token, userAlias, pageSize, lastItem) {
        // TODO: Replace with the result of calling server
        const { followers, hasMore } = await this.followDAO.getFollowers(userAlias, pageSize, lastItem?.alias);
        return [followers, hasMore];
    }
    ;
    async loadMoreFollowees(token, userAlias, pageSize, lastItem) {
        const { followees, hasMore } = await this.followDAO.getFollowees(userAlias, pageSize, lastItem?.alias);
        return [followees, hasMore];
    }
    ;
    async getIsFollowerStatus(token, userAlias, selectedUserAlias) {
        // TODO: Replace with the result of calling server
        return this.followDAO.getFollowStatus(userAlias, selectedUserAlias);
    }
    ;
    async getFolloweeCount(userAlias) {
        // TODO: Replace with the result of calling server
        console.log("Getting followee count for " + userAlias);
        return this.followDAO.getFolloweeCount(userAlias);
    }
    ;
    async getFollowerCount(userAlias) {
        // TODO: Replace with the result of calling server
        console.log("Getting follower count for " + userAlias);
        return this.followDAO.getFollowerCount(userAlias);
    }
    ;
    async follow(currentUserAlias, userToFollow) {
        await this.followDAO.follow(currentUserAlias, userToFollow);
        console.log(currentUserAlias + " followed " + userToFollow);
    }
    ;
    async unfollow(currentUserAlias, userToUnfollow) {
        await this.followDAO.unfollow(currentUserAlias, userToUnfollow);
    }
    ;
    async getAllFollowers(userAlias) {
        return this.followDAO.getAllFollowers(userAlias);
    }
    async *getFollowersPaginated(userAlias, batchSize = 10) {
        for await (const followerBatch of this.followDAO.getFollowersPaginated(userAlias, batchSize)) {
            yield followerBatch;
        }
    }
}
exports.FollowService = FollowService;
