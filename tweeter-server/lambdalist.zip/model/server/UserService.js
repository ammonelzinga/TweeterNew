"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const uuid_1 = require("uuid");
const AuthenticationService_1 = require("./AuthenticationService");
class UserService {
    userDAO;
    authDAO;
    profileImageDAO;
    authService;
    constructor(userDAO, authDAO, profileImageDAO) {
        this.userDAO = userDAO;
        this.authDAO = authDAO;
        this.profileImageDAO = profileImageDAO;
        this.authService = new AuthenticationService_1.AuthenticationService(this.authDAO);
    }
    async register(firstName, lastName, alias, password, imageStringBase64, imageFileExtension) {
        // Not neded now, but will be needed when you make the request to the server in milestone 3
        /*const imageStringBase64: string =
          Buffer.from(userImageBytes).toString("base64");*/
        //convert imageStringBase64 to userImageBytes Uint8array??
        // TODO: Replace with the result of calling the server
        const fileName = `${alias}_` + (0, uuid_1.v4)() + '.' + imageFileExtension;
        const imageUrl = await this.profileImageDAO.uploadProfileImage(fileName, imageStringBase64);
        const user = {
            alias: alias,
            firstName: firstName,
            lastName: lastName,
            password: password,
            imageUrl: imageUrl
        };
        const hashedPassword = await bcryptjs_1.default.hash(password, 10);
        await this.userDAO.registerUser(user, hashedPassword, imageUrl);
        const authToken = await this.authService.createAuthToken(alias);
        if (!authToken) {
            throw new Error("[Bad Request] Invalid registration");
        }
        return [user, authToken];
    }
    ;
    async login(alias, password) {
        // TODO: Replace with the result of calling the server
        const { user, isValid } = await this.userDAO.validateUserCredentials(alias, password);
        if (!isValid || user === null) {
            throw new Error("[Bad Request] Invalid alias or password");
        }
        const authToken = await this.authService.createAuthToken(alias);
        if (!authToken) {
            throw new Error("[Bad Request] Invalid login");
        }
        return [user, authToken];
    }
    ;
    async logout(token) {
        this.authService.deleteAuthToken(token);
    }
    ;
    async getUser(token, alias) {
        // TODO: Replace with the result of calling server
        const user = await this.userDAO.getUserByAlias(alias);
        if (user === null) {
            throw new Error("[Bad Request] User not found");
        }
        return user;
    }
    ;
}
exports.UserService = UserService;
