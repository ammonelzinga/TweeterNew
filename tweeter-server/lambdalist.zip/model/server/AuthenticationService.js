"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthenticationService = void 0;
const tweeter_shared_1 = require("tweeter-shared");
class AuthenticationService {
    authoDAO;
    SESSION_TIME = 1000 * 60 * 10; // 10 minutes
    constructor(authoDAO) {
        this.authoDAO = authoDAO;
    }
    async isAuthorized(tokenString, userAlias) {
        const authToken = await this.authoDAO.getAuthToken(tokenString, userAlias);
        if (!authToken) {
            throw new Error("[Bad Request] Invalid auth token");
        }
        const currentTime = Date.now();
        if (currentTime - authToken.timestamp > this.SESSION_TIME) {
            await this.authoDAO.deleteAuthToken(tokenString);
            throw new Error("[Bad Request] Auth token has expired");
        }
        await this.authoDAO.updateAuthTimestamp(tokenString);
        return true;
    }
    async createAuthToken(userAlias) {
        const authToken = tweeter_shared_1.AuthToken.Generate();
        await this.authoDAO.putAuthToken(authToken, userAlias);
        return authToken.token;
    }
    async deleteAuthToken(tokenString) {
        await this.authoDAO.deleteAuthToken(tokenString);
    }
}
exports.AuthenticationService = AuthenticationService;
