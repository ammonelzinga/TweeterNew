"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.S3ProfileImageDAO = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
class S3ProfileImageDAO {
    bucketName = "tweetprofilepicbucket";
    region = "us-west-2";
    client;
    constructor() {
        this.client = new client_s3_1.S3Client({ region: this.region });
    }
    async uploadProfileImage(fileName, imageStringBase64Encoded) {
        let decodedImageBuffer = Buffer.from(imageStringBase64Encoded, "base64");
        const s3Params = {
            Bucket: this.bucketName,
            Key: "image/" + fileName,
            Body: decodedImageBuffer,
            ContentType: "image/png"
        };
        const c = new client_s3_1.PutObjectCommand(s3Params);
        try {
            await this.client.send(c);
            return (`https://${this.bucketName}.s3.${this.region}.amazonaws.com/image/${fileName}`);
        }
        catch (error) {
            throw Error("s3 put image failed with: " + error);
        }
    }
}
exports.S3ProfileImageDAO = S3ProfileImageDAO;
