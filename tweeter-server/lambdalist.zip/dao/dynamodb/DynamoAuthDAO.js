"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoAuthDAO = void 0;
const tweeter_shared_1 = require("tweeter-shared");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
class DynamoAuthDAO {
    tableName = "auth_tokens";
    client;
    constructor() {
        const dynamoClient = new client_dynamodb_1.DynamoDBClient({ region: "us-west-2" });
        this.client = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient);
    }
    async putAuthToken(token, userAlias) {
        const command = new lib_dynamodb_1.PutCommand({
            TableName: this.tableName,
            Item: {
                "token": token.token,
                "userAlias": userAlias,
                "timestamp": token.timestamp
            }
        });
        await this.client.send(command);
    }
    async getAuthToken(tokenString, userAlias) {
        const command = new lib_dynamodb_1.GetCommand({
            TableName: this.tableName,
            Key: { token: tokenString }
        });
        const response = await this.client.send(command);
        if (!response.Item) {
            return null;
        }
        return new tweeter_shared_1.AuthToken(response.Item.token, Number(response.Item.timestamp));
    }
    async deleteAuthToken(tokenString) {
        const command = new lib_dynamodb_1.DeleteCommand({
            TableName: this.tableName,
            Key: { token: tokenString }
        });
        await this.client.send(command);
    }
    //using the #ts stuff in case dynamodb has a timestamp reserved word, seemed like a good idea so stuck with it
    async updateAuthTimestamp(tokenString) {
        const command = new lib_dynamodb_1.UpdateCommand({
            TableName: this.tableName,
            Key: { token: tokenString },
            UpdateExpression: "SET #ts = :newTimestamp",
            ExpressionAttributeNames: {
                "#ts": "timestamp"
            },
            ExpressionAttributeValues: {
                ":newTimestamp": Date.now()
            }
        });
        await this.client.send(command);
    }
}
exports.DynamoAuthDAO = DynamoAuthDAO;
