"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoStatusDAO = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const DynamoFollowDAO_1 = require("./DynamoFollowDAO");
class DynamoStatusDAO {
    storyTable = 'story';
    feedTable = 'feed';
    client;
    followDAO;
    constructor() {
        const dynamoClient = new client_dynamodb_1.DynamoDBClient({ region: "us-west-2" });
        this.client = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient);
        this.followDAO = new DynamoFollowDAO_1.DynamoFollowDAO();
    }
    /*
    async postStatus(status: StatusDto): Promise<void> {

        const timestamp = status.timestamp;

        const user_block = {
            alias: status.user.alias,
            firstName: status.user.firstName,
            lastName: status.user.lastName,
            imageUrl: status.user.imageUrl
        };

        await this.client.send(new PutCommand({
            TableName: this.storyTable,
            Item: {
                user_alias: status.user.alias,
                timestamp: timestamp,
                post: status.post,
                segments: status.segments,
                user: user_block
            }
        }));

        const followers = await this.followDAO.getAllFollowers(status.user.alias);
        if (followers.length === 0) {
            return;
        }

        const feedWrites = followers.map(follower => ({
            PutRequest: {
                Item: {
                    user_alias: follower.alias,
                    timestamp: timestamp,
                    post: status.post,
                    segments: status.segments,
                    user: user_block
                }
            }
        }));

        const BATCH_SIZE = 25;
        const batches = [];
        for (let i = 0; i < feedWrites.length; i += BATCH_SIZE) {
            batches.push(feedWrites.slice(i, i + BATCH_SIZE));
        }

        for(const batch of batches) {
            await this.client.send(new BatchWriteCommand({
                RequestItems: {
                    [this.feedTable]: batch
                }
            }));
        }
        
    } */
    async writeToStory(status) {
        const timestamp = status.timestamp;
        const user_block = {
            alias: status.user.alias,
            firstName: status.user.firstName,
            lastName: status.user.lastName,
            imageUrl: status.user.imageUrl
        };
        await this.client.send(new lib_dynamodb_1.PutCommand({
            TableName: this.storyTable,
            Item: {
                user_alias: status.user.alias,
                timestamp: timestamp,
                post: status.post,
                segments: status.segments,
                user: user_block
            }
        }));
    }
    async writeStatusToFeed(followerAlias, status) {
        const user_block = {
            alias: status.user.alias,
            firstName: status.user.firstName,
            lastName: status.user.lastName,
            imageUrl: status.user.imageUrl
        };
        const params = {
            TableName: this.feedTable,
            Item: {
                user_alias: followerAlias,
                timestamp: status.timestamp,
                post: status.post,
                segments: status.segments,
                user: user_block
            }
        };
        await this.client.send(new lib_dynamodb_1.PutCommand(params));
    }
    async getStoryItems(userAlias, limit, lastStatus) {
        const params = {
            TableName: this.storyTable,
            KeyConditionExpression: "user_alias = :ua",
            ExpressionAttributeValues: {
                ":ua": userAlias
            },
            Limit: limit,
            ScanIndexForward: false
        };
        if (lastStatus) {
            params.ExclusiveStartKey = {
                user_alias: userAlias,
                timestamp: lastStatus.timestamp
            };
        }
        const data = await this.client.send(new lib_dynamodb_1.QueryCommand(params));
        const statuses = (data.Items ?? []).map(item => ({
            user: item.user,
            post: item.post,
            timestamp: item.timestamp,
            segments: item.segments
        }));
        return { statuses, hasMore: data.LastEvaluatedKey ? true : false };
    }
    async getFeedItems(userAlias, limit, lastStatus) {
        const params = {
            TableName: this.feedTable,
            KeyConditionExpression: "user_alias = :ua",
            ExpressionAttributeValues: {
                ":ua": userAlias
            },
            Limit: limit,
            ScanIndexForward: false
        };
        if (lastStatus) {
            params.ExclusiveStartKey = {
                user_alias: userAlias,
                timestamp: lastStatus.timestamp
            };
        }
        const data = await this.client.send(new lib_dynamodb_1.QueryCommand(params));
        const statuses = (data.Items ?? []).map(item => ({
            user: item.user,
            post: item.post,
            timestamp: item.timestamp,
            segments: item.segments
        }));
        return { statuses, hasMore: data.LastEvaluatedKey ? true : false };
    }
}
exports.DynamoStatusDAO = DynamoStatusDAO;
