"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const UserService_1 = require("../../model/server/UserService");
const dynamoFactory_1 = require("../../factory/dynamoFactory");
const handler = async (request) => {
    const factory = new dynamoFactory_1.dynamoFactory();
    const userService = new UserService_1.UserService(factory.createUserDAO(), factory.createAuthenticationDAO(), factory.createProfileImageDAO());
    //I am assuming registration does not need authorization check until after they are registered, so doing it there
    const [userDto, token] = await userService.register(request.firstName, request.lastName, request.userAlias, request.password, request.imageStringBase64, request.imageFileExtension);
    return {
        success: true,
        message: null,
        userDto: userDto,
        token: token
    };
};
exports.handler = handler;
