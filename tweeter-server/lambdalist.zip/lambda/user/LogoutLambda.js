"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const UserService_1 = require("../../model/server/UserService");
const AuthenticationService_1 = require("../../model/server/AuthenticationService");
const dynamoFactory_1 = require("../../factory/dynamoFactory");
const handler = async (request) => {
    const factory = new dynamoFactory_1.dynamoFactory();
    const authService = new AuthenticationService_1.AuthenticationService(factory.createAuthenticationDAO());
    const isAuthorized = await authService.isAuthorized(request.token, request.userAlias);
    if (!isAuthorized) {
        throw new Error("Unauthorized");
    }
    const userService = new UserService_1.UserService(factory.createUserDAO(), factory.createAuthenticationDAO(), factory.createProfileImageDAO());
    await userService.logout(request.token);
    return {
        success: true,
        message: null,
    };
};
exports.handler = handler;
