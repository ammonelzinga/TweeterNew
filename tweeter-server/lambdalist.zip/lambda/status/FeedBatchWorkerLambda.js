"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const StatusService_1 = require("../../model/server/StatusService");
const dynamoFactory_1 = require("../../factory/dynamoFactory");
const handler = async (event, context) => {
    const factory = new dynamoFactory_1.dynamoFactory();
    const statusService = new StatusService_1.StatusService(factory.createStatusDAO());
    const FEED_TABLE_NAME = process.env.FEED_TABLE_NAME;
    for (const record of event.Records) {
        const feedBatchMessage = JSON.parse(record.body);
        try {
            await statusService.writeStatusToFeed(feedBatchMessage.user_alias, feedBatchMessage.status);
        }
        catch (e) {
            console.error(`Error writing status to feed for user ${feedBatchMessage.user_alias}:`, e);
        }
    }
};
exports.handler = handler;
