"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const dynamoFactory_1 = require("../../factory/dynamoFactory");
const AuthenticationService_1 = require("../../model/server/AuthenticationService");
const FollowService_1 = require("../../model/server/FollowService");
const handler = async (request) => {
    const factory = new dynamoFactory_1.dynamoFactory();
    const authService = new AuthenticationService_1.AuthenticationService(factory.createAuthenticationDAO());
    const isAuthorized = await authService.isAuthorized(request.token, request.userAlias);
    if (!isAuthorized) {
        throw new Error("Unauthorized");
    }
    const followService = new FollowService_1.FollowService(factory.createFollowDAO());
    await followService.unfollow(request.userAlias, request.selectedUserAlias);
    return {
        success: true,
        message: null,
    };
};
exports.handler = handler;
