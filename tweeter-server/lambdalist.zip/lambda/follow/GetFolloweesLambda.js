"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const FollowService_1 = require("../../model/server/FollowService");
const AuthenticationService_1 = require("../../model/server/AuthenticationService");
const dynamoFactory_1 = require("../../factory/dynamoFactory");
const handler = async (request) => {
    const factory = new dynamoFactory_1.dynamoFactory();
    const authService = new AuthenticationService_1.AuthenticationService(factory.createAuthenticationDAO());
    const isAuthorized = await authService.isAuthorized(request.token, request.userAlias);
    if (!isAuthorized) {
        throw new Error("Unauthorized");
    }
    const followService = new FollowService_1.FollowService(factory.createFollowDAO());
    const [items, hasMore] = await followService.loadMoreFollowees(request.token, request.userAlias, request.pageSize, request.lastItem);
    return {
        success: true,
        message: null,
        items: items,
        hasMore: hasMore
    };
};
exports.handler = handler;
